#!/bin/bash

# Directorio donde se guardan los backups por defecto
DIRECTORIO_BACKUP_POR_DEFECTO="/backup_dir"

# Función de ayuda
mostrar_ayuda() {
    echo "Uso: $0 [OPCIONES] <origen> <destino>"
    echo "  <origen>   : El directorio o archivo que se va a respaldar."
    echo "  <destino>  : El directorio donde se guardará la copia de seguridad."
    echo "               Si no se especifica, se usará $DIRECTORIO_BACKUP_POR_DEFECTO."
    echo ""
    echo "Opciones:"
    echo "  -h, --help : Muestra esta ayuda."
    echo ""
    echo "Ejemplos:"
    echo "  $0 /var/log"
    echo "  $0 /var/www /backup_dir/mis_backups"
}

# Procesar argumentos
ORIGEN=""
DESTINO=""

while [[ "$#" -gt 0 ]]; do
    case "$1" in
        -h|--help)
            mostrar_ayuda
            exit 0
            ;;
        *)
            if [[ -z "$ORIGEN" ]]; then
                ORIGEN="$1"
            elif [[ -z "$DESTINO" ]]; then
                DESTINO="$1"
            else
                echo "Error: Demasiados argumentos."
                mostrar_ayuda
                exit 1
            fi
            ;;
    esac
    shift
done

# Validar que se haya proporcionado un origen
if [[ -z "$ORIGEN" ]]; then
    echo "Error: Se debe especificar un directorio o archivo de origen."
    mostrar_ayuda
    exit 1
fi

# Asignar destino por defecto si no se especifica
if [[ -z "$DESTINO" ]]; then
    DESTINO="$DIRECTORIO_BACKUP_POR_DEFECTO"
fi

# Validar que el origen y destino existan y sean accesibles
if [[ ! -e "$ORIGEN" ]]; then
    echo "Error: El origen '$ORIGEN' no existe."
    exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
    echo "Error: El directorio de destino '$DESTINO' no existe o no es un directorio."
    exit 1
fi

# Validar que los sistemas de archivos de origen y destino estén montados
# Para el origen, si es un archivo o directorio dentro de un FS montado, se asume disponible.
# Para el destino, verificamos que el punto de montaje de /backup_dir esté disponible.
PUNTO_MONTAJE_DESTINO=$(df -P "$DESTINO" | awk 'NR==2 {print $6}')

if [[ -z "$PUNTO_MONTAJE_DESTINO" || ! -d "$PUNTO_MONTAJE_DESTINO" ]]; then
    echo "Error: El sistema de archivos de destino para '$DESTINO' no parece estar montado o no es accesible."
    exit 1
fi

# Obtener solo el nombre del directorio/archivo de origen sin la ruta
NOMBRE_BASE=$(basename "$ORIGEN")

# Generar la fecha en formato YYYYMMDD
FORMATO_FECHA=$(date +%Y%m%d)

# Construir el nombre del archivo de backup
NOMBRE_ARCHIVO_BACKUP="${NOMBRE_BASE}_bkp_${FORMATO_FECHA}.tar.gz"
RUTA_COMPLETA_BACKUP="${DESTINO}/${NOMBRE_ARCHIVO_BACKUP}"

echo "Iniciando backup de '$ORIGEN' a '$RUTA_COMPLETA_BACKUP'..."

# Crear el backup
tar -czPf "$RUTA_COMPLETA_BACKUP" "$ORIGEN"

# Verificar si el backup fue exitoso
if [[ $? -eq 0 ]]; then
    echo "Backup completado exitosamente: '$RUTA_COMPLETA_BACKUP'"
else
    echo "Error: El backup de '$ORIGEN' falló."
    exit 1
fi

exit 0